import numpy as np
import cv2
import matplotlib.pyplot as plt

def safe_load_npy(path):
    arr = np.load(path)
    return arr

def create_bev_height(points, x_min=-50, x_max=50, y_min=-50, y_max=50, resolution=0.1, z_clip=(-3,5)):
    x = points[:,0]
    y = points[:,1]
    z = points[:,2]
    z = np.clip(z, z_clip[0], z_clip[1])
    W = int(np.ceil((x_max - x_min) / resolution))
    H = int(np.ceil((y_max - y_min) / resolution))
    ix = np.floor((x - x_min) / resolution).astype(int)
    iy = np.floor((y - y_min) / resolution).astype(int)
    mask = (ix >= 0) & (ix < W) & (iy >= 0) & (iy < H)
    ix, iy, z = ix[mask], iy[mask], z[mask]
    height_grid = np.full((H, W), -np.inf, dtype=np.float32)

    
    
    for cx, cy, cz in zip(ix, iy, z):
        if cz > height_grid[cy, cx]:
            height_grid[cy, cx] = cz

    min_z = np.min(z) if z.size > 0 else z_clip[0]
    height_grid[~np.isfinite(height_grid)] = min_z

    meta = {
        "H": H, "W": W, "resolution": resolution,
        "x_min": x_min, "x_max": x_max, "y_min": y_min, "y_max": y_max
    }
    return height_grid, meta

def onclick(event, height_grid, meta):
    if event.xdata is None or event.ydata is None:
        return
    x_click = event.xdata
    y_click = event.ydata
    ix = int((x_click - meta['x_min']) / meta['resolution'])
    iy = int((y_click - meta['y_min']) / meta['resolution'])
    H, W = meta['H'], meta['W']
    if 0 <= ix < W and 0 <= iy < H:
        height = height_grid[iy, ix]
        print(f"Clicked at X={x_click:.2f}, Y={y_click:.2f} -> Height = {height:.3f} meters")
    else:
        print("Clicked outside BEV area")

if __name__ == "__main__":
    lidar_path = r"C:\Users\OFA3KOR\Desktop\IDD_DATASET\lidar\d0\fi.npy"
    points = safe_load_npy(lidar_path)

    height_grid, meta = create_bev_height(points, x_min=-50, x_max=50, y_min=-50, y_max=50, resolution=0.1)

    extent = [meta['x_min'], meta['x_max'], meta['y_min'], meta['y_max']]
    plt.figure(figsize=(8,8))
    plt.imshow(height_grid, origin='lower', extent=extent, cmap='viridis')
    plt.colorbar(label='Height (m)')
    plt.title("BEV Height Map ")
    plt.xlabel("X (m)")
    plt.ylabel("Y (m)")








    plt.gcf().canvas.mpl_connect('button_press_event', lambda event: onclick(event, height_grid, meta))
    plt.show()
