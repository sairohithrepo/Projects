from controller import Robot, Camera, Lidar, GPS, InertialUnit, Motor
import math

robot = Robot()
timestep = int(robot.getBasicTimeStep())

camera = robot.getDevice("front_camera")
camera.enable(timestep)

lidar = robot.getDevice("front_lidar")
lidar.enable(timestep)

gps = robot.getDevice("gps")
gps.enable(timestep)

imu = robot.getDevice("imu")
imu.enable(timestep)

# Get motors
front_left_motor = robot.getDevice("front left wheel motor")
front_right_motor = robot.getDevice("front right wheel motor")
rear_left_motor = robot.getDevice("rear left wheel motor")
rear_right_motor = robot.getDevice("rear right wheel motor")

for motor in [front_left_motor, front_right_motor, rear_left_motor, rear_right_motor]:
    motor.setPosition(float('inf'))
    motor.setVelocity(0.0)

MAX_SPEED = 10.0
speed = 5.0

def set_speed(left, right):
    front_left_motor.setVelocity(left)
    front_right_motor.setVelocity(right)
    rear_left_motor.setVelocity(left)
    rear_right_motor.setVelocity(right)

# Basic autonomous loop
while robot.step(timestep) != -1:
    lidar_values = lidar.getRangeImage()
    front_dist = sum(lidar_values[:10]) / 10
    if front_dist < 5.0:
        # Obstacle avoidance
        set_speed(-2, 2)
    else:
        # Go straight
        set_speed(speed, speed)
