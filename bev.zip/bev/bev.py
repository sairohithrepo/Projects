import numpy as np
import cv2
import json
import os
from PIL import Image
import pandas as pd
import matplotlib.pyplot as plt

# --- Part 1: All Data Loading Functions ---

def find_first_file_with_extension(root_folder, extensions):
    """
    Recursively searches for the first file with a given extension.
    This handles subdirectories like 'd0', 'd1', etc.
    """
    if not os.path.exists(root_folder):
        return None
    for dirpath, _, filenames in os.walk(root_folder):
        for filename in filenames:
            if filename.lower().endswith(tuple(ext.lower() for ext in extensions)):
                return os.path.join(dirpath, filename)
    return None

def load_lidar_from_file(file_path):
    """Loads LiDAR points from an Excel OR a CSV file (case-insensitive)."""
    try:
        if file_path.endswith('.csv'):
            df = pd.read_csv(file_path)
        else: # Assume Excel
            df = pd.read_excel(file_path)
        
        # --- THE FIX IS HERE ---
        # We create a lowercase version of the column names to make matching case-insensitive.
        df_columns_lower = [col.lower() for col in df.columns]

        # Now we look for the lowercase versions of our desired names.
        possible_x_cols = ['x', 'point_index_x'] # A common alternative
        possible_y_cols = ['y']
        possible_z_cols = ['z']
        possible_intensity_cols = ['intensity']
        
        col_x = next((col for col in possible_x_cols if col.lower() in df_columns_lower), None)
        col_y = next((col for col in possible_y_cols if col.lower() in df_columns_lower), None)
        col_z = next((col for col in possible_z_cols if col.lower() in df_columns_lower), None)
        col_i = next((col for col in possible_intensity_cols if col.lower() in df_columns_lower), None)

        if not all([col_x, col_y, col_z, col_i]):
            print(f"Error: Could not find required x, y, z, intensity columns in {file_path}")
            print(f"Found columns: {df.columns.tolist()}")
            return None

        # We use the original column names from the dataframe to select the data
        original_col_x = df.columns[df_columns_lower.index(col_x)]
        original_col_y = df.columns[df_columns_lower.index(col_y)]
        original_col_z = df.columns[df_columns_lower.index(col_z)]
        original_col_i = df.columns[df_columns_lower.index(col_i)]

        point_cloud = df[[original_col_x, original_col_y, original_col_z, original_col_i]].to_numpy()
        return point_cloud
    except Exception as e:
        print(f"Error loading LiDAR file {file_path}: {e}")
        return None

def load_camera_image(img_path):
    """Loads a camera image using PIL."""
    try:
        image = Image.open(img_path).convert("RGB")
        return np.array(image)
    except Exception as e:
        print(f"Error loading image file {img_path}: {e}")
        return None

# --- Part 2: Calibration and Transformation Functions ---

def load_custom_calibration(calib_path):
    with open(calib_path, 'r') as f:
        calib = json.load(f)
    cam_data = calib['camera_front_left']
    K_cam = np.array([[cam_data['intrinsic']['fx'], 0, cam_data['intrinsic']['cx']], [0, cam_data['intrinsic']['fy'], cam_data['intrinsic']['cy']], [0, 0, 1]])
    t_cam = np.array(cam_data['extrinsic']['translation_meters']).reshape(3, 1)
    r_cam_deg = np.array(cam_data['extrinsic']['rotation_degrees'])
    r_cam_rad = np.deg2rad(r_cam_deg)
    rx, ry, rz = r_cam_rad
    R_x = np.array([[1, 0, 0], [0, np.cos(rx), -np.sin(rx)], [0, np.sin(rx), np.cos(rx)]])
    R_y = np.array([[np.cos(ry), 0, np.sin(ry)], [0, 1, 0], [-np.sin(ry), 0, np.cos(ry)]])
    R_z = np.array([[np.cos(rz), -np.sin(rz), 0], [np.sin(rz), np.cos(rz), 0], [0, 0, 1]])
    R_cam = R_z @ R_y @ R_x
    lidar_data = calib['lidar']
    t_lid = np.array(lidar_data['extrinsic']['translation_meters']).reshape(3, 1)
    r_lid_deg = np.array(lidar_data['extrinsic']['rotation_degrees'])
    r_lid_rad = np.deg2rad(r_lid_deg)
    rx, ry, rz = r_lid_rad
    R_x = np.array([[1, 0, 0], [0, np.cos(rx), -np.sin(rx)], [0, np.sin(rx), np.cos(rx)]])
    R_y = np.array([[np.cos(ry), 0, np.sin(ry)], [0, 1, 0], [-np.sin(ry), 0, np.cos(ry)]])
    R_z = np.array([[np.cos(rz), -np.sin(rz), 0], [np.sin(rz), np.cos(rz), 0], [0, 0, 1]])
    R_lid = R_z @ R_y @ R_x
    return K_cam, R_cam, t_cam, R_lid, t_lid

def transform_lidar_to_camera(points_lidar, R_cam, t_cam, R_lid, t_lid):
    R_lid_to_veh = R_lid.T
    t_lid_to_veh = -R_lid_to_veh @ t_lid
    ones = np.ones((points_lidar.shape[0], 1), dtype=np.float32)
    points_lidar_homo = np.hstack([points_lidar[:, :3], ones])
    points_veh = (R_lid_to_veh @ points_lidar_homo.T).T + t_lid_to_veh.T
    R_cam_to_veh = R_cam.T
    t_cam_to_veh = -R_cam_to_veh @ t_cam
    points_veh_homo = np.hstack([points_veh, ones])
    points_cam = (R_cam_to_veh @ points_veh_homo.T).T + t_cam_to_veh.T
    return points_cam[:, :3]

def project_points_to_image(points_camera, K_cam, image_shape):
    points_3d = points_camera[:, :3]
    valid_depth_mask = points_3d[:, 2] > 0.1
    points_3d_valid = points_3d[valid_depth_mask]
    points_2d_homo = (K_cam @ points_3d_valid.T).T
    points_2d = points_2d_homo[:, :2] / points_2d_homo[:, 2, np.newaxis]
    img_h, img_w = image_shape[:2]
    valid_image_mask = (points_2d[:, 0] >= 0) & (points_2d[:, 0] < img_w) & (points_2d[:, 1] >= 0) & (points_2d[:, 1] < img_h)
    final_points_2d = points_2d[valid_image_mask].astype(int)
    final_points_3d = points_3d_valid[valid_image_mask]
    original_indices = np.where(valid_depth_mask)[0][valid_image_mask]
    return final_points_2d, final_points_3d, original_indices

def create_bev_from_colored_cloud(colored_points, bev_size=(512, 512), view_range=(25, 25)):
    w_bev, h_bev = bev_size
    view_width_m, view_height_m = view_range
    bev_image = np.zeros((h_bev, w_bev, 3), dtype=np.uint8)
    bev_depth_map = np.full((h_bev, w_bev), np.inf)
    x_pixels = ((colored_points[:, 0] + view_width_m / 2) / view_width_m * w_bev).astype(int)
    y_pixels = ((-colored_points[:, 1] + view_height_m) / view_height_m * h_bev).astype(int)
    valid_bev_mask = (x_pixels >= 0) & (x_pixels < w_bev) & (y_pixels >= 0) & (y_pixels < h_bev)
    x_valid = x_pixels[valid_bev_mask]
    y_valid = y_pixels[valid_bev_mask]
    colors_valid = colored_points[valid_bev_mask, 4:7]
    z_valid = colored_points[valid_bev_mask, 2]
    for i in range(len(x_valid)):
        if z_valid[i] < bev_depth_map[y_valid[i], x_valid[i]]:
            bev_image[y_valid[i], x_valid[i]] = colors_valid[i]
            bev_depth_map[y_valid[i], x_valid[i]] = z_valid[i]
    return bev_image

# --- Part 3: Main Execution Script ---

def main():
    # --- Configuration ---
    # IMPORTANT: Change ONLY this one line to the path of your scene folder
    SCENE_ROOT = "C:/Users/OFA3KOR/Desktop/IDD_DATASET" 
    
    # --- Robust File Discovery ---
    img_path = find_first_file_with_extension(os.path.join(SCENE_ROOT, "left_view"), ['.jpg', '.jpeg', '.png'])
    lidar_path = find_first_file_with_extension(os.path.join(SCENE_ROOT, "lidar_points"), ['.csv', '.xlsx', '.xls'])
    calib_path = os.path.join(SCENE_ROOT, "sensor_calibration.json")

    if not img_path:
        print(f"Error: Could not find any image file in '{os.path.join(SCENE_ROOT, 'left_view')}'")
        return
    if not lidar_path:
        print(f"Error: Could not find any LiDAR CSV/Excel file in '{os.path.join(SCENE_ROOT, 'lidar_points')}'")
        return
    if not os.path.exists(calib_path):
        print(f"Error: Calibration file not found at {calib_path}")
        return

    print(f"Found image: {img_path}")
    print(f"Found LiDAR file: {lidar_path}")
    print(f"Found calibration file: {calib_path}")

    # 1. Load all data
    print("\nLoading data...")
    image = load_camera_image(img_path)
    lidar_points_raw = load_lidar_from_file(lidar_path)
    K_cam, R_cam, t_cam, R_lid, t_lid = load_custom_calibration(calib_path)
    
    if image is None or lidar_points_raw is None:
        print("Failed to load essential data. Exiting.")
        return
        
    print("Data loaded successfully.")

    # 2. Transform LiDAR points to the camera coordinate system
    print("Transforming LiDAR points to camera frame...")
    points_cam = transform_lidar_to_camera(lidar_points_raw, R_cam, t_cam, R_lid, t_lid)
    
    # 3. Project camera-frame points onto the 2D image
    print("Projecting points to image plane...")
    projected_points_2d, projected_points_3d, original_indices = project_points_to_image(points_cam, K_cam, image.shape)

    # 4. "Paint" the LiDAR points with image colors
    print("Painting point cloud with image colors...")
    colored_points = np.zeros((len(projected_points_2d), 7)) 
    colored_points[:, :3] = projected_points_3d
    for i, (u, v) in enumerate(projected_points_2d):
        colored_points[i, 4:7] = image[v, u] / 255.0
        
    # 5. Create the final BEV image
    print("Generating BEV...")
    bev_image = create_bev_from_colored_cloud(colored_points)
    print("BEV generation complete.")

    # 6. Visualize the results
    plt.figure(figsize=(15, 7))
    plt.subplot(1, 2, 1)
    plt.imshow(image)
    plt.title("Original Camera Image")
    plt.axis('off')
    plt.subplot(1, 2, 2)
    plt.imshow(bev_image)
    plt.title("Final BEV (LiDAR + Camera)")
    plt.axis('off')
    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    main()