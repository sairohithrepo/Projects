import numpy as np
import cv2
import json
import os
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
from sklearn.cluster import DBSCAN

# --- Part 1: Data Loading Functions (Robust and Flexible) ---

def find_first_file_with_extension(root_folder, extensions):
    """Recursively searches for the first file with a given extension."""
    if not os.path.exists(root_folder):
        print(f"ERROR: Directory not found: {root_folder}")
        return None
    for dirpath, _, filenames in os.walk(root_folder):
        for filename in filenames:
            if filename.lower().endswith(tuple(ext.lower() for ext in extensions)):
                return os.path.join(dirpath, filename)
    return None

def load_lidar_from_file(file_path):
    """
    Loads LiDAR points from an Excel OR a CSV file.
    This version is robust to different column names, including 'file_name' and 'point_index'.
    """
    print(f"Attempting to load LiDAR from: {file_path}")
    if not os.path.exists(file_path):
        print(f"ERROR: LiDAR file not found at {file_path}")
        return None
    try:
        df = pd.read_csv(file_path) if file_path.endswith('.csv') else pd.read_excel(file_path)
        
        # Create a lowercase version of column names for easy matching
        df_columns_lower = [col.lower() for col in df.columns]
        
        # Define all possible names for our data
        possible_x_cols = ['x', 'point_index_x', 'file_name'] # Added 'file_name'
        possible_y_cols = ['y']
        possible_z_cols = ['z']
        possible_i_cols = ['intensity']

        # Find the actual columns in the dataframe
        col_x = next((col for col in possible_x_cols if col in df_columns_lower), None)
        col_y = next((col for col in possible_y_cols if col in df_columns_lower), None)
        col_z = next((col for col in possible_z_cols if col in df_columns_lower), None)
        col_i = next((col for col in possible_i_cols if col in df_columns_lower), None)

        if not all([col_x, col_y, col_z, col_i]):
            print(f"ERROR: Could not find required x, y, z, intensity columns in {file_path}")
            print(f"Found columns: {df.columns.tolist()}")
            return None

        # Get the original column names to select the data
        original_col_x = df.columns[df_columns_lower.index(col_x)]
        original_col_y = df.columns[df_columns_lower.index(col_y)]
        original_col_z = df.columns[df_columns_lower.index(col_z)]
        original_col_i = df.columns[df_columns_lower.index(col_i)]

        point_cloud = df[[original_col_x, original_col_y, original_col_z, original_col_i]].to_numpy()
        print(f"SUCCESS: Loaded LiDAR point cloud with {point_cloud.shape[0]} points.")
        return point_cloud
    except Exception as e:
        print(f"CRITICAL ERROR: An exception occurred while reading the LiDAR file: {e}")
        return None

def load_camera_image(img_path):
    """Loads a camera image using PIL."""
    if not os.path.exists(img_path):
        print(f"ERROR: Image file not found at {img_path}")
        return None
    try:
        image = Image.open(img_path).convert("RGB")
        print(f"SUCCESS: Loaded camera image with shape {image.size}.")
        return np.array(image)
    except Exception as e:
        print(f"CRITICAL ERROR: An exception occurred while loading the image: {e}")
        return None

def load_lidar_calibration(calib_path):
    """Loads LiDAR extrinsic calibration from a JSON file."""
    if not os.path.exists(calib_path):
        print(f"ERROR: Calibration file not found at {calib_path}")
        return None
    try:
        with open(calib_path, 'r') as f:
            calib = json.load(f)
            print(f"SUCCESS: Loaded calibration for LiDAR.")
            
            lidar_data = calib['lidar']
            t_lid = np.array(lidar_data['extrinsic']['translation_meters']).reshape(3, 1)
            r_lid_deg = np.array(lidar_data['extrinsic']['rotation_degrees'])
            r_lid_rad = np.deg2rad(r_lid_deg)
            
            # Create a full 4x4 transformation matrix from yaw, pitch, roll
            rx, ry, rz = r_lid_rad
            R_x = np.array([[1, 0, 0], [0, np.cos(rx), -np.sin(rx)], [0, np.sin(rx), np.cos(rx)]])
            R_y = np.array([[np.cos(ry), 0, np.sin(ry)], [0, 1, 0], [-np.sin(ry), 0, np.cos(ry)]])
            R_z = np.array([[np.cos(rz), -np.sin(rz), 0], [np.sin(rz), np.cos(rz), 0], [0, 0, 1]])
            R_lid = R_z @ R_y @ R_x
            
            return R_lid, t_lid
    except Exception as e:
        print(f"CRITICAL ERROR: Failed to parse the calibration file: {e}")
        return None

def transform_lidar_to_vehicle(points_lidar, R_lid, t_lid):
    """
    Transforms LiDAR points from the LiDAR sensor's frame to the vehicle frame.
    Includes a sanity check for empty input.
    """
    print("...Executing transform_lidar_to_vehicle.")
    
    # SANITY CHECK 1: Check if input LiDAR data is empty
    if points_lidar.shape[0] == 0:
        print("WARNING: Input LiDAR point cloud is empty. Returning empty vehicle points.")
        return np.array([]) # Return an empty array
    
    points_lidar_xyz = points_lidar[:, :3]
    R_lid_to_veh = R_lid.T
    t_lid_to_veh = -R_lid_to_veh @ t_lid
    
    points_veh = (R_lid_to_veh @ points_lidar_xyz.T).T + t_lid_to_veh.T
    
    print(f"DEBUG: Transform returned {points_veh.shape[0]} vehicle points.")
    return points_veh

def project_points_to_image(points_camera, K_cam, image_shape):
    """Projects 3D points in the camera coordinate system onto the 2D image plane."""
    points_3d = points_camera[:, :3]
    valid_depth_mask = points_3d[:, 2] > 0.1
    points_3d_valid = points_3d[valid_depth_mask]
    points_2d_homo = (K_cam @ points_3d_valid.T).T
    points_2d = points_2d_homo[:, :2] / points_2d_homo[:, 2, np.newaxis]
    img_h, img_w = image_shape[:2]
    valid_image_mask = (points_2d[:, 0] >= 0) & (points_2d[:, 0] < img_w) & (points_2d[:, 1] >= 0) & (points_2d[:, 1] < img_h)
    final_points_2d = points_2d[valid_image_mask].astype(int)
    final_points_3d = points_3d_valid[valid_image_mask]
    return final_points_2d, final_points_3d

def create_bev_from_lidar(points_veh, lidar_points_raw, bev_size=(512, 512), view_range=(25, 25), ground_filter_height_m=0.5):
    # ...
    x_pixels = ((ground_points[:, 0] + view_width_m / 2) / view_width_m * w_bev).astype(int)
    y_pixels = ((-ground_points[:, 1] + view_height_m) / view_height_m * h_bev).astype(int)
    # ...
    valid_bev_mask = (x_pixels >= 0) & (x_pixels < w_bev) & (y_pixels >= 0) & (y_pixels < h_bev)
    
    x_valid = x_pixels[valid_bev_mask]
    y_valid = y_valid[valid_bev_mask]
    intensities_valid = intensities[valid_bev_mask]
    
    print(f"DEBUG: Found {len(x_valid)} valid points to draw on BEV.")

    # Normalize intensity to 0-255 range for grayscale
    min_i, max_i = intensities_valid.min(), intensities_valid.max()
    if max_i > min_i:
        colors = ((intensities_valid - min_i) / (max_i - min_i) * 255).astype(np.uint8)
    else:
        colors = np.zeros_like(intensities_valid, dtype=np.uint8)

    # Apply a colormap for better visualization
    cmap = plt.get_cmap('viridis')
    norm = mcolors.Normalize(vmin=0, vmax=255)
    colored_pixels_map = (cmap(norm(colors)) * 255).astype(np.uint8)

    # Draw the points on the BEV image
    bev_image = np.zeros((h_bev, w_bev), 3), dtype=np.uint8)
    bev_depth_map = np.full((h_bev, w_bev), np.inf)
    x_pixels = ((ground_points[:, 0] + view_width_m / 2) / view_width_m * w_bev).astype(int)
    y_pixels = ((-ground_points[:, 1] + view_height_m) / view_height_m * h_bev).astype(int)
    valid_bev_mask = (x_pixels >= 0) & (x_pixels < w_bev) & (y_pixels >= 0) & (y_pixels < h_bev)
    
    x_valid = x_pixels[valid_bev_mask]
    y_valid = y_valid[valid_bev_mask]
    intensities_valid = intensities[valid_bev_mask]
    
    print(f"DEBUG: Found {len(x_valid)} valid points to draw on BEV.")

    # Normalize intensity to 0-255 range for grayscale
    min_i, max_i = intensities_valid.min(), intensities_valid.max()
    if max_i > min_i:
        colors = ((intensities_valid - min_i) / (max_i - min_i) * 255).astype(np.uint8)
    else:
        colors = np.zeros_like(intensities_valid, dtype=np.uint8)

    # Apply a colormap for better visualization
    cmap = plt.get_cmap('viridis')
    norm = mcolors.Normalize(vmin=0, vmax=255)
    colored_pixels_map = (cmap(norm(colors)) * 255).astype(np.uint8)

    # Draw the points on the BEV image
    bev_image[y_valid, x_valid] = colored_pixels_map
    
    print(f"SUCCESS: Created BEV image with shape {bev_image.shape}.")
    return bev_image

def detect_3d_objects_on_bev(points_veh, eps=0.5, min_samples=10):
    """
    Detects 3D objects using DBSCAN clustering on the point cloud in vehicle coordinates.
    This is a placeholder for more advanced object detection.
    """
    print("...Executing 3D object detection (DBSCAN)...")
    db = DBSCAN(eps=eps, min_samples=min_samples).fit(points_veh)
    labels = db.labels_
    bboxes_3d = []
    for label in set(labels):
        if label == -1: continue  # Ignore noise points
        cluster = points_veh[labels == label]
        min_coords = np.min(cluster, axis=0)
        max_coords = np.max(cluster, axis=0)
        bboxes_3d.append((min_coords, max_coords))
    print(f"Detected {len(bboxes_3d)} 3D objects.")
    return bboxes_3d

def draw_3d_bboxes_on_bev(bev_image, bboxes_3d, view_range=(25, 25), bev_size=(512, 512)):
    """
    Draws 2D bounding boxes on a BEV image from 3D coordinates.
    This is a placeholder. More advanced methods exist for precise 3D box fitting.
    """
    w_bev, h_bev = bev_size
    view_width_m, view_height_m = view_range
    for min_coords, max_coords in bboxes_3d:
        # Convert 3D vehicle coordinates to BEV pixel coordinates
        x1, y1, _ = min_coords
        x2, y2, _ = max_coords
        px1 = int((x1 + view_width_m / 2) / view_width_m * w_bev)
        py1 = int((-y1 + view_height_m) / view_height_m * h_bev)
        px2 = int((x2 + view_width_m / 2) / view_width_m * w_bev)
        py2 = int((-y2 + view_height_m) / view_height_m * h_bev)
        # Draw the rectangle on the BEV image
        cv2.rectangle(bev_image, (px1, py1), (px2, py2), (0, 255, 0), 2) # Green box
    return bev_image

# --- Part 3: Main Execution Script (Complete and Commented) ---

def main():
    """
    Main function to execute the BEV generation pipeline.
    """
    # --- Configuration ---
    # IMPORTANT: Change ONLY this one line to the path of your scene folder
    SCENE_ROOT = "C:/Users/OFA3KOR/Desktop/IDD_DATASET"
    
    # --- Robust File Discovery ---
    lidar_path = find_first_file_with_extension(os.path.join(SCENE_ROOT, "lidar_points"), ['.csv', '.xlsx', '.xls'])
    calib_path = os.path.join(SCENE_ROOT, "sensor_calibration.json")

    if not lidar_path:
        print("ERROR: Could not find any LiDAR CSV/Excel file. Exiting.")
        return
    if not os.path.exists(calib_path):
        print("ERROR: Calibration file not found. Exiting.")
        return

    print(f"Found LiDAR file: {lidar_path}")
    print(f"Found calibration file: {calib_path}")

    # 1. Load all data
    print("\n===== STEP 1: LOADING DATA =====")
    lidar_points_raw = load_lidar_from_file(lidar_path)
    R_lid, t_lid = load_lidar_calibration(calib_path)
    
    # CRITICAL CHECK: Did the data loading actually succeed?
    if lidar_points_raw is None:
        print("CRITICAL: Data loading failed. Cannot proceed.")
        return
        
    print("SUCCESS: All essential data loaded.")

    # 2. Transform LiDAR points to the vehicle coordinate system
    print("\n===== STEP 2: TRANSFORMING TO VEHICLE FRAME =====")
    points_veh = transform_lidar_to_vehicle(lidar_points_raw, R_lid, t_lid)
    
    # 3. Create the final BEV image
    print("\n===== STEP 3: GENERATING BEV IMAGE =====")
    # You can adjust these parameters to change the resolution and view area
    # bev_size=(512, 512) -> 512x512 pixels
    # view_range=(25, 25) -> 25m x 25m real-world area
    bev_image = create_bev_from_lidar(points_veh, lidar_points_raw, bev_size=bev_size, view_range=view_range)
    print("BEV generation complete.")

    # 4. (Optional) Perform 3D Object Detection
    # This is where you would add more advanced logic
    print("\n===== STEP 4: (OPTIONAL) 3D OBJECT DETECTION =====")
    bboxes_3d = detect_3d_objects_on_bev(points_veh)
    bev_with_detections = draw_3d_bboxes_on_bev(bev_image.copy(), bboxes_3d)
    print(f"Detected {len(bboxes_3d)} objects and drew bounding boxes.")

    # 5. Visualize the results
    print("\n===== STEP 5: VISUALIZATION =====")
    plt.figure(figsize=(20, 10))

    # Plot 1: Raw LiDAR Point Cloud (Top-Down View)
    ax1 = plt.subplot(2, 3, 1)
    ax1.scatter(lidar_points_raw[:, 0], -lidar_points_raw[:, 1], c='gray', s=0.1, cmap='viridis')
    ax1.set_title("1. Raw LiDAR Point Cloud (Vehicle Frame)")
    ax1.set_xlabel("X (meters)")
    ax1.set_ylabel("Y (meters)")
    ax1.set_aspect('equal', adjustable='box')
    ax1.grid(True)
    
    # Plot 2: Final BEV from LiDAR
    ax2 = plt.subplot(2, 3, 2)
    ax2.imshow(bev_image)
    ax2.set_title("2. Final BEV from LiDAR")
    ax2.axis('off')
    
    # Plot 3: Final BEV with 3D Detections (if performed)
    if 'bboxes_3d' in locals() and len(bboxes_3d) > 0:
        ax3 = plt.subplot(2, 3, 3)
        ax3.imshow(bev_with_detections)
        ax3.set_title("3. BEV with 3D Object Detections")
        ax3.axis('off')

    plt.tight_layout()
    plt.show()

    # 6. (Optional) Save the final BEV image
    # This is a great practice for saving your results
    output_dir = "output_bev_images"
    os.makedirs(output_dir, exist_ok=True)
    output_path = os.path.join(output_dir, "final_lidar_bev.png")
    cv2.imwrite(output_path, bev_image)
    print(f"SUCCESS: Saved final BEV image to {output_path}")


if __name__ == "__main__":
    main()