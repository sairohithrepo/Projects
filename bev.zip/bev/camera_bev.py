import cv2
import numpy as np

# ---------------------------------------------------------
# Step 1: Load Image
# ---------------------------------------------------------
img = cv2.imread(r"C:\Users\OFA3KOR\Desktop\IDD_DATASET\left_view\d0\leftCamImgs\0000001.jpg")
h, w = img.shape[:2]

# ---------------------------------------------------------
# Step 2: Define 4 Source Points (Points on Road in front-view)
# You MUST adjust these four points according to your image.
# Pick corners of the road in your input image.
# ---------------------------------------------------------
src_points = np.float32([
    [w*0.2, h*0.9],   # bottom-left road line
    [w*0.55, h*0.60],   # bottom-right road line
    [w*0.15, h*0.90],   # top-left road
    [w*0.85, h*0.90]    # top-right road
])

# ---------------------------------------------------------
# Step 3: Define Destination Points (Top-down rectangle)
# BEV output resolution
# ---------------------------------------------------------
bev_width = 500
bev_height = 600

dst_points = np.float32([
    [0, bev_height],          # bottom-left
    [bev_width, bev_height],  # bottom-right
    [0, 0],                   # top-left
    [bev_width, 0]            # top-right
])

# ---------------------------------------------------------
# Step 4: Compute Homography
# ---------------------------------------------------------
H, _ = cv2.findHomography(src_points, dst_points)

# ---------------------------------------------------------
# Step 5: Warp image → BEV output
# ---------------------------------------------------------
bev_image = cv2.warpPerspective(img, H, (bev_width, bev_height))

# ---------------------------------------------------------
# Step 6: Display
# ---------------------------------------------------------
cv2.imshow("Original Image", img)
cv2.imshow("BEV Image", bev_image)
cv2.waitKey(0)
cv2.destroyAllWindows()
